leJOS EV3 0.8.0 release
=======================

See the [Wiki](https://sourceforge.net/p/lejos/wiki/Getting%20started%20with%20leJOS%20EV3/) for how to install leJOS EV3.

On Windows, you should use the .exe installer.

On Linux and MAC OSX, you can use the .tar.gz distribution.

