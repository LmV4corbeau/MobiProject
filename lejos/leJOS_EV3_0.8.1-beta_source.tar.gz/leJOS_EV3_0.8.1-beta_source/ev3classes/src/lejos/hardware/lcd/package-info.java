/**
 * Access to the EV3 LCD
 */
package lejos.hardware.lcd;