package lejos.robotics.geometry;

public class Rectangle extends java.awt.geom.Rectangle2D.Float {

	public Rectangle(float x, float y, float w, float h) {
		super(x,y,w,h);
	}

}
