/**
 * Filters for sample providers.
 */
package lejos.robotics.filter;