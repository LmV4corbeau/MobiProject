/**
 * Provides out-of-the-box neural networks
 */

package org.neuroph.nnet;

