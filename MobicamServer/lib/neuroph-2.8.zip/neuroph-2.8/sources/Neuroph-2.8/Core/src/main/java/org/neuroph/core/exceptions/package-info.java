/**
 * Provides specific exceptions when working with neural networks
 */

package org.neuroph.core.exceptions;

