/**
 * Provides data set related classes and manipulation methods.
 */
package org.neuroph.core.data;
