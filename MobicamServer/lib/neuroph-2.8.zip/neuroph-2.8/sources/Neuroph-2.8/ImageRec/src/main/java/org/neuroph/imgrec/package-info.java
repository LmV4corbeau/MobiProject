/**
 * Provides classes for image recognition with neural networks.
 */

package org.neuroph.imgrec;